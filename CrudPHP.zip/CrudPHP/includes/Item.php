<?php
class Item
{
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function create($name, $description)
    {
        $stmt = $this->conn->prepare("INSERT INTO items (name, description) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $description);
        $stmt->execute();
        return $stmt->insert_id;
    }

    public function read()
    {
        $result = $this->conn->query("SELECT * FROM items");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function update($id, $name, $description)
    {
        $stmt = $this->conn->prepare("UPDATE items SET name = ?, description = ? WHERE id = ?");
        $stmt->bind_param("ssi", $name, $description, $id);
        return $stmt->execute();
    }

    public function delete($id)
    {
        $stmt = $this->conn->prepare("DELETE FROM items WHERE id = ?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
?>
