<?php
require_once 'config.php';
require_once 'includes/Item.php';

$item = new Item($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create'])) {
        $name = $_POST['name'];
        $description = $_POST['description'];
        $item->create($name, $description);
    } elseif (isset($_POST['update'])) {
        $id = $_POST['id'];
        $name = $_POST['name'];
        $description = $_POST['description'];
        $item->update($id, $name, $description);
    } elseif (isset($_POST['delete'])) {
        $id = $_POST['id'];
        $item->delete($id);
    }
}

$items = $item->read();
?>

<!DOCTYPE html>
<html>

<head>
    <title>CRUD Application</title>
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
</head>

<body>
    <div class="container">
        <h1>CRUD Application</h1>
        <form method="post">
            <input type="text" name="name" placeholder="Name">
            <input type="text" name="description" placeholder="Description">
            <button type="submit" name="create">Create</button>
        </form>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Action</th>
            </tr>
            <?php foreach ($items as $row) : ?>
                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= $row['name']; ?></td>
                    <td><?= $row['description']; ?></td>
                    <td>
                        <form method="post">
                            <input type="hidden" name="id" value="<?= $row['id']; ?>">
                            <input type="text" name="name" value="<?= $row['name']; ?>">
                            <input type="text" name="description" value="<?= $row['description']; ?>">
                            <button type="submit" name="update">Update</button>
                            <button type="submit" name="delete">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>

</html>
